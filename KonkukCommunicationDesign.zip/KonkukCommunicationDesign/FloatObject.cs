﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;
using System.IO;
using System.Windows.Media.Effects;

namespace KonkukCommunicationDesign
{
    public class FloatObject
    {
        public static readonly Random RANDOM = new Random((int)DateTime.Now.Ticks);
        public double Scale = 1;
        public Point3D Position { get; set; }

        CeilingWindow ceiling;
        WallDisplayWindow wall;
        Canvas ceilingCanvas;
        Canvas wallCanvas;

        public Thread thread;
        Boolean upFlag = false;
        System.Windows.Controls.Image wallEllipse;
        System.Windows.Controls.Image ceilingEllipse;
        public static Random random = new Random((int)System.DateTime.Now.Ticks);

        double upVelocity;

        RotateTransform rotateTransform;
        BlurEffect blurEffect;
        double degree;

        public FloatObject(CeilingWindow ceiling, WallDisplayWindow wall, double x)
        {
            this.ceiling = ceiling;
            this.wall = wall;
            this.ceilingCanvas = ceiling.CanvasForObject;
            this.wallCanvas = wall.CanvasForObject;

            init(x);
        }
        int imageIndex;
        void init(double x)
        {
            //double x = RANDOM.NextDouble() * wall.Width;
            double y = 0;
            double z = 0;
            wall.Dispatcher.Invoke(() =>
            {
                y = 150; // wall.Height;
                z = RANDOM.NextDouble() * ceiling.Height - Preferences.ObjectHeight;

                Position = new Point3D(x, y, z);
                imageIndex = random.Next(bubbles.Length);
                // 그리드에 추가
                wallEllipse = new System.Windows.Controls.Image(); // new Ellipse();
                wallEllipse.Width = 10; // Preferences.ObjectWidth;
                wallEllipse.Height = 10; // Preferences.ObjectHeight;

                // Rotation 
                wallEllipse.RenderTransformOrigin = new System.Windows.Point(0.5, 0.5);
                rotateTransform = new RotateTransform();
                wallEllipse.RenderTransform = new RotateTransform(0);

                // Blur Effect 초기화
                blurEffect = new BlurEffect();
                blurEffect.Radius = 0;

               

                wallEllipse.Source = bubbleFrames[imageIndex];

                //wallEllipse.Fill = new SolidColorBrush(Colors.White);
                Thickness margin = new Thickness();
                margin.Left = x;
                margin.Top = y;
                wallEllipse.Margin = margin;

                wallCanvas.Children.Add(wallEllipse);

                thread = new Thread(new ThreadStart(this.up));
                thread.Start();
            });
            
            

            
        }

        bool increase = true;
        

        void up()
        {
            double distHallX = 0;
            double distHallY = 0;
            double targetX = 0, targetY = 0;
            bool isOpen = false;
            int count = -1;
            int div = 100;
            double x = 0;
            double y = 0;
            double diff = 0;

            bool creating = true;
            int creatingTimer = 0;
            try
            {
            
                for (int i = 0; true; i++)
                {
                    if (!isOpen &&  CeilingWindow.isValidHall)
                    {
                        targetX = ceiling.windowWidth - (CeilingWindow.hallX / ceiling.frameWidth * ceiling.windowWidth) - (Preferences.ObjectWidth/2);
                        targetY = (CeilingWindow.hallY / ceiling.frameHeight * ceiling.windowHeight) - (Preferences.ObjectWidth / 2);
                        count = -1;
                        isOpen = true;
                    }
                    else if(!CeilingWindow.isValidHall)
                    {
                        isOpen = false;
                        count = -1;
                    }

                    wallCanvas.Dispatcher.Invoke(() =>
                    {
                        if (wallEllipse != null)
                        {
                            if (creating)
                            {
                                Thickness margin = wallEllipse.Margin;

                                wallEllipse.Width += 1;
                                wallEllipse.Height += 1;

                                margin.Left -= 0.5;
                                margin.Top -= 0.5;
                                wallEllipse.Margin = margin;

                                creatingTimer++;

                                if (creatingTimer == 190)
                                {
                                    creating = false;
                                }

                                
                            }
                            else
                            {
                                Thickness margin = wallEllipse.Margin;
                                margin.Top -= 2;

                                rotateTransform.Angle += 0.1;
                                wallEllipse.RenderTransform = rotateTransform;
                                wallEllipse.Margin = margin;
                            }

                            // wall.log.Content = margin.Top.ToString();
                        }


                        

                        
                        if (ceilingEllipse != null)
                        {
                            /*if (CeilingWindow.initialDepth != null && CeilingWindow.closerDepth != Int32.MaxValue)
                            {
                                if (Utils.isChangedDepthOnCeiling(CeilingWindow.closerDepth,
                                    CeilingWindow.closerDepthIndex,
                                    CeilingWindow.initialDepth))
                                {
                                    Thickness margin = ceilingEllipse.Margin;


                                    if (CeilingWindow.closerDepth != Int32.MaxValue && !isOpen && diff > 200)
                                    {
                                        isOpen = true;

                                        // 현재 좌표
                                        distHallX = (x - margin.Left) / 150;
                                        distHallY = (y - margin.Top) / 150;
                                        
                                    }
                                    
                                    if (isOpen && diff > 200)
                                    {
                                        // 이동
                                        margin.Left += distHallX;
                                        margin.Top += distHallY;
                                        count++;
                                        ceilingEllipse.Margin = margin;
                                        if (count == 150)
                                        {
                                            ceiling.CanvasForObject.Children.Remove(ceilingEllipse);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        isOpen = false;
                                    }


                                    

                                    

                                    //일단 방향 1씩 이동

                                    //MarkerIndex.Content = string.Format("{0}, {1}, depth {2}", (int)x, (int)y, currentFrameCloser);
                                    //Canvas.SetLeft(DepthMarker, x);
                                    //Canvas.SetTop(DepthMarker, y);
                                }
                            } */

                            // 홀로 들어갈 때
                            if (CeilingWindow.isValidHall)
                            {
                                double left = Canvas.GetLeft(ceilingEllipse);
                                double top = Canvas.GetTop(ceilingEllipse);

                                if (isOpen && count == -1)
                                {
                                    distHallX = (targetX - left) / div;
                                    distHallY = (targetY - top) / div;
                                    count = 0;
                                }

                                Canvas.SetLeft(ceilingEllipse, left + distHallX);
                                Canvas.SetTop(ceilingEllipse, top + distHallY);

                                Position.x = Canvas.GetLeft(ceilingEllipse);
                                Position.z = Canvas.GetTop(ceilingEllipse);

                                if (count == div)
                                {
                                    ceiling.CanvasForObject.Children.Remove(ceilingEllipse);
                                    return;
                                }
                                count++;

                                


                            }

                            ///
                            /// 천장에서 상하 운동 하는 경우
                            ///
                            else
                            {
                                isOpen = false;

                                if (Position.z > Canvas.GetTop(ceilingEllipse))
                                {
                                    if (increase)
                                    {
                                        Scale += Preferences.ScaleDiff;

                                        if (Scale > 1.8)
                                        {
                                            increase = false;
                                        }
                                    }
                                    else
                                    {
                                        Scale -= Preferences.ScaleDiff;

                                        if (Scale < 1)
                                        {
                                            increase = true;
                                        }
                                    }

                                    ceilingEllipse.Width = Preferences.ObjectWidth * Scale;
                                    ceilingEllipse.Height = Preferences.ObjectHeight * Scale;

                                    //ceilingEllipse.Effect = new BlurEffect();
                                    ceilingEllipse.Opacity = (Scale - 0.7) / 2;

                                    double width = ceilingEllipse.Width;
                                    double height = ceilingEllipse.Height;

                                    // 위치 조정
                                    Canvas.SetLeft(ceilingEllipse, Position.x + (Preferences.ObjectWidth - width) / 2);
                                    Canvas.SetTop(ceilingEllipse, Position.z + (Preferences.ObjectHeight - height) / 2);
                                    // 스케일 조정
                                    //ceilingEllipse.Tran
                                }
                                else
                                {
                                    Canvas.SetTop(ceilingEllipse, Canvas.GetTop(ceilingEllipse)- 2);
                                }
                            }
                        
                        }

                        if (wallEllipse != null && wallEllipse.Margin.Top + Preferences.ObjectHeight < 0)
                        {
                            wallEllipse = null;
                        }

                        if (!upFlag && wallEllipse.Margin.Top < 0)
                        {
                            Thickness margin = wallEllipse.Margin;
                            ceilingEllipse = new System.Windows.Controls.Image();
                            //ceilingEllipse.Fill = new SolidColorBrush(Colors.White);
                            ceilingEllipse.Source = bubbleFrames[imageIndex];
                            ceilingEllipse.Width = Preferences.ObjectWidth;
                            ceilingEllipse.Height = Preferences.ObjectHeight;

                            ceiling.CanvasForObject.Children.Add(ceilingEllipse);

                            Thickness wallMargin = wallEllipse.Margin;

                            Canvas.SetLeft(ceilingEllipse, wallMargin.Left / wall.Width * ceiling.Width);
                            Canvas.SetTop(ceilingEllipse, ceiling.Height - Preferences.Distance);

                            Position.x = Canvas.GetLeft(ceilingEllipse);
                            upFlag = true;
                        }
                    });

                    Thread.Sleep(Preferences.FPS);
                }

            }
            catch (TaskCanceledException e)
            {
               
            }
        }

        public static Bitmap[] bubbles = {
                                             Properties.Resources.bubbles_01,
                                             Properties.Resources.bubbles_02,
                                             Properties.Resources.bubbles_03,
                                             Properties.Resources.bubbles_04,
                                             Properties.Resources.bubbles_05,
                                         };

        public static BitmapFrame[] bubbleFrames = null;

        
     
        
    }

}
